#include "aim.h"
#include <algorithm>

Vec3 bone_point(const PlayerInfo& p, int bone, float lead) {
    static const float H[3] = {1.62f, 1.15f, 0.55f};       // head, body, legs (standing, metres above feet)
    float h = H[bone < 0 ? 0 : bone > 2 ? 2 : bone];
    if (p.crouch) h *= 0.78f;
    return {p.pos.x + p.vel.x * lead, p.pos.y + h, p.pos.z + p.vel.z * lead};
}

AimOut aim_step(const Snapshot& s, const AimCfg& c, int sticky) {
    AimOut o;
    if (!c.on || !s.valid) return o;
    Cam cam = s.cam;
    cam.fovY = eff_fov(cam.fovY, c.fovScale, c.fovHoriz, c.W / c.H);
    const float cx = c.W * 0.5f, cy = c.H * 0.5f;
    float best = 1e9f;
    const PlayerInfo* bp = nullptr;
    Vec3 bpt;
    for (auto& p : s.players) {
        if (p.local || p.dead) continue;
        bool mate = p.mate || (s.localTeam >= 1 && s.localTeam <= 2 && p.team == s.localTeam);
        if (mate && c.teamCheck) continue;
        if (len(p.pos - cam.pos) > c.maxDist) continue;
        Vec3 pt = bone_point(p, c.bone, c.leadMs / 1000.f);
        float sx, sy;
        if (!w2s(cam, pt, c.W, c.H, sx, sy)) continue;
        float d = std::sqrt((sx - cx) * (sx - cx) + (sy - cy) * (sy - cy));
        bool st = p.actor == sticky;
        if (d > c.fovPx * (st ? 1.3f : 1.f)) continue;
        if (st) d *= 0.5f;                     // hysteresis: keep the current target
        if (d < best) { best = d; bp = &p; bpt = pt; }
    }
    if (!bp) return o;

    const float R2D = 180.f / 3.14159265f;
    Vec3 f = norm(cam.fwd), dv = norm(bpt - cam.pos);
    float curYaw = std::atan2(f.x, f.z), curPitch = std::asin(std::max(-1.f, std::min(1.f, f.y)));
    float tYaw = std::atan2(dv.x, dv.z), tPitch = std::asin(std::max(-1.f, std::min(1.f, dv.y)));
    o.dyaw = wrap_pi(tYaw - curYaw) * R2D;
    o.dpitch = (tPitch - curPitch) * R2D;
    o.errDeg = std::sqrt(o.dyaw * o.dyaw + o.dpitch * o.dpitch);
    o.has = true; o.actor = bp->actor; o.point = bpt; o.dir = dv;
    return o;
}

static float wrap180(float a) { while (a > 180.f) a -= 360.f; while (a < -180.f) a += 360.f; return a; }

bool AimCtl::observe(float yaw, float pitch, bool injecting) {
    bool ch = !have_ || std::fabs(wrap180(yaw - lastYaw_)) > 1e-3f || std::fabs(pitch - lastPitch_) > 1e-3f;
    if (have_ && ch && injecting) { wYaw_ += wrap180(yaw - lastYaw_); wPit_ += pitch - lastPitch_; }
    if (ch) { lastYaw_ = yaw; lastPitch_ = pitch; have_ = true; }
    return ch;
}

void AimCtl::idle() { h0x_ = h0y_ = h1x_ = h1y_ = 0; wPx_ = wPy_ = wYaw_ = wPit_ = 0; winStart_ = 0; }

bool AimCtl::step(const AimOut& a, const AimCfg& c, double t, float& dx, float& dy) {
    dx = dy = 0;
    if (!a.has) return false;
    if (cfgPpd_ != c.ppd || ppdX == 0) { cfgPpd_ = c.ppd; ppdX = c.ppd; ppdY = -c.ppd * (c.invY ? -1.f : 1.f); }
    if (winStart_ == 0) winStart_ = t;

    // what we already sent but the camera has not shown yet (input -> game -> camera takes about 1.5 frames)
    float inYaw = (h0x_ + 0.5f * h1x_) / ppdX, inPit = (h0y_ + 0.5f * h1y_) / ppdY;
    float ey = a.dyaw - inYaw, ep = a.dpitch - inPit;
    float gain = c.mode == 1 ? 0.9f : std::max(0.03f, std::min(1.f, c.smooth));
    float cap = c.mode == 1 ? c.maxStep * 4.f : c.maxStep;
    if (std::sqrt(ey * ey + ep * ep) > 0.12f) {
        dx = ey * gain * ppdX;
        dy = ep * gain * ppdY;
        float m = std::sqrt(dx * dx + dy * dy);
        if (m > cap) { dx *= cap / m; dy *= cap / m; }
    }
    h1x_ = h0x_; h1y_ = h0y_; h0x_ = dx; h0y_ = dy;
    wPx_ += dx; wPy_ += dy;

    if (t - winStart_ >= 0.6) {                      // learning window: total px sent vs total angle the camera moved
        if (std::fabs(wPx_) > 30.f && std::fabs(wYaw_) > 0.4f) {
            float r = wPx_ / wYaw_;
            if (std::fabs(r) > 0.25f * c.ppd && std::fabs(r) < 4.f * c.ppd) ppdX = (r * ppdX < 0) ? r : 0.6f * ppdX + 0.4f * r;
        }
        if (std::fabs(wPy_) > 30.f && std::fabs(wPit_) > 0.4f) {
            float r = wPy_ / wPit_;
            if (std::fabs(r) > 0.25f * c.ppd && std::fabs(r) < 4.f * c.ppd) ppdY = (r * ppdY < 0) ? r : 0.6f * ppdY + 0.4f * r;
        }
        wPx_ = wPy_ = wYaw_ = wPit_ = 0; winStart_ = t;
    }
    return true;
}
